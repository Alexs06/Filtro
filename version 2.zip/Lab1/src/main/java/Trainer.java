
import java.util.Hashtable;
import java.util.List;
import java.util.ArrayList;
public class Trainer {
    int spamTotal;
    int noSpamTotal;
    public void showData(){

    };

    public Hashtable trainFilter(List<Email> noSpam, List<Email> spam,Hashtable hash){
        return hash;
    };

}
