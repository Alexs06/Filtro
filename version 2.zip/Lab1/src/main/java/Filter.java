import java.util.Hashtable;


public class Filter {
    Trainer trainer = new Trainer();
    Hashtable<String,Term> probs;
    Calculator calculator;
    public Trainer getTrainer() {
        return trainer;
    }

    public void setTrainer(Trainer trainer) {
        this.trainer = trainer;
    }

    public void clasifyEmail(){

    }

}
