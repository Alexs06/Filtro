import java.nio.file.Files;
public class FileManager {

    public String readFile(String s) {
        return "";
    }

    public void writeFile(String s) {

    }
}
