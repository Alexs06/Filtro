import java.util.List;

public class Calculator {

    public double bayesianProbability(List<Email> e){
        double prob=0.0;
        return prob;

    }

    public void calculateProbability(Term t){

    }
}
