import java.util.Scanner;
import java.io.IOException;

public class Menu {
    Authenticator ac;
    Scanner sc;
    int opc = 0;

    public Menu() {
        ac=new Authenticator();
        //sc = new Scanner();
    }

    public int introMenu(){
        System.out.println("Option Menu");
        System.out.println("Do you want to:");
        System.out.println("1.Autenticate");
        System.out.println("2.Exit");
        opc=sc.nextInt();
        if(opc == 1) {
            return 1;
        }
        else {
           System.out.println("Bye");
           return 0;
        }
    }

    public void showMenu2() {

        Scanner sc = new Scanner(System.in);
        System.out.println("Option Menu");
        System.out.println("Do you want to:");
        System.out.println("1.Configurate");
        System.out.println("2.Train the filter");
        System.out.println("3.Exit");

    }

    public int showAuthenticatorMenu(){ //
        ac.logIn();
        System.out.println("1.Configuration");
        System.out.println("2.Train");
        System.out.println("3.Show data ");
        System.out.println("4.Get new email");
        System.out.println("5.Logout");
        System.out.println("0.Exit");
        while (opc!=0)
        opc =sc.nextInt();
        switch (opc) {
            case 1:
                return 1;

            case 2:
                return 2;


            case 3:
                return 3;

            case 4:
                return 4;


            case 5:
                return 5;


            default:
                System.out.println("Invalid input");
        }
        return 0;
    }
    public void showConfigurationMenu(){
        Configuration con=new Configuration();
        Scanner sc = new Scanner(System.in);
        String ans="";
        int opc=0;
        System.out.println("Configuration Menu");
        System.out.println("1.Spam probability");
        System.out.println("2.Spam Threshold probability");
        System.out.println("3.Training Size");
        opc =sc.nextInt();

        switch (opc){
            case 1:
                System.out.println("The default spam probability value is 3.0");
                System.out.println("Do you want to change it? Y/N");
                ans =sc.nextLine();
                //
                //
                if(ans == "Y"|| ans =="y") {
                    double prob;
                    System.out.println("Set the new probability: ");
                    prob=sc.nextDouble();
                    con.setSpamProbability(prob);
                }
                break;
            case 2:
                System.out.println("The default threshold probability value is 9.0");
                System.out.println("Do you want to change it? Y/N");
                ans =sc.nextLine();
                //
                //
                if(ans == "Y"|| ans =="y") {
                    double prob;
                    System.out.println("Set the new probability: ");
                    prob=sc.nextDouble();
                    con.setspamThreshold(prob);
                }

                break;
            case 3:
                System.out.println("Set the new Training Size (interger):");
                int size = sc.nextInt();
                con.setTrainingSize(size);
                break;
            default:
                System.out.println("Set a correct value: ");
                break;
        }

    }
    public void showFilterMenu(){

    }
}
