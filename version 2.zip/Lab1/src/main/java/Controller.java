import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.services.gmail.Gmail;
import com.google.api.client.json.jackson2.JacksonFactory;

import javax.naming.AuthenticationException;
import java.io.IOException;
import java.security.GeneralSecurityException;

public class Controller {


    public static void main(String... args) throws IOException, GeneralSecurityException {
    GmailAPI api;
    api = new GmailAPI();
    api.exc();
       /* Menu menu = new Menu();
        Authenticator authenticator = new Authenticator();
        Configuration configuration= new Configuration();
        Filter filter = new Filter();
        ConfigurationParser parser= new ConfigurationParser();
        FileManager fileManager = new FileManager();
        EmailLoader emailLoader = new EmailLoader();
        Trainer trainer= new Trainer();
        int opc;
        int inpu;
        opc = menu.introMenu();
        if(opc ==1)
        {
            authenticator.logIn();
            inpu = menu.showAuthenticatorMenu();
                switch (inpu){
                    case 1:
                        menu.showConfigurationMenu();
                        break;
                    case 2:
                        break;
                        //grfilter.


                }
            }

        else{
            System.out.println("Bye");
        }
*/
    }
}
