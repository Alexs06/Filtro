import com.google.api.services.gmail.Gmail;
import com.google.api.services.gmail.model.ListMessagesResponse;
import com.google.api.services.gmail.model.Message;
import com.google.api.services.gmail.model.MessagePartHeader;

import java.io.IOException;



import java.util.ArrayList;
import java.util.List;

public class EmailLoader {


    public ArrayList<Email> getNewMail(Gmail service, String label, long totalEmail) throws IOException {

        Gmail.Users.Messages.List request = service.users().messages().list("me");
        request.setQ("is:" + label).setMaxResults(totalEmail);
        ListMessagesResponse listMessagesResponse = request.execute();

        //Get new mail from a message list
        List<Message> emailMessagesResponse = listMessagesResponse.getMessages();
        ArrayList<Email> emailList = new ArrayList<>();
        if (emailMessagesResponse == null) {
            return emailList;
        } else {
            Email email = new Email();
            for (Message message : emailMessagesResponse) {
                email = email.toEmail(message);
                emailList.add(email);
            }
            System.out.println("\nEmails: \n");
            int msgCounter = 1;
            for (Message msgIterator : emailMessagesResponse) {


                if (msgCounter <= totalEmail) {

                    System.out.println("Email details #" + (msgCounter) + ": \n");
                    Message msgCurrent = service.users().messages().get("me", msgIterator.getId()).setFormat("full").execute();

                    for (MessagePartHeader header : msgCurrent.getPayload().getHeaders()) {
                        if (header.getName().contains("Date") || header.getName().contains("From") || header.getName().contains("To") || header.getName().contains("Subject")) {
                            String headerCurrent = (header.getName() + ": " + header.getValue());
                            System.out.println(" - " + headerCurrent);
                        }
                    }

                }
            }
        }
        return emailList;
    }
}


